package edu.waketech.measurable;

public interface Measurable {
	int getMeasure();
}
